<ul class="sidebar navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <!-- Admin -->
    <?php if(auth()->user()->role == 'Admin'): ?>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('konfirmasipem.index')); ?>">
        <i class="fas fa-fw fa-clipboard-check"></i>
        <span>Verifikasi Pembayaran</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dp.index')); ?>">
        <i class="fas fa-fw fa-table"></i>
        <span>Data Pengajar</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="/Maqdis/jadwal-pengajar">
      <i class="fas fa-fw fa-clipboard-list"></i>
      <span>Jadwal Pengajar</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('ds.index')); ?>">
      <i class="fas fa-fw fa-table"></i>
      <span>Data Peserta</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('jpeserta.index')); ?>">
      <i class="fas fa-fw fa-clipboard-list"></i>
      <span>Jadwal Peserta</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('absen.index')); ?>">
      <i class="fas fa-fw fa-book"></i>
      <span>Rekap Kehadiran</span></a>
    </li>
    <li class="nav-item">
    
    <!-- Super Admin -->
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('pengguna.index')); ?>">
      <i class="fas fa-fw fa-users"></i>
      <span>Data Pengguna</span></a>
    </li>
    <!-- /super admin -->
    <?php endif; ?>
    <!-- /admin -->

    <!-- Pengajar -->
    <?php if(auth()->user()->role == 'Pengajar'): ?>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('absen.pengajar')); ?>">
      <i class="fas fa-fw fa-calendar-check"></i>
      <span>Absensi</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('jadwal.pengajar')); ?>">
      <i class="fas fa-fw fa-clipboard-list"></i>
      <span>Jadwal</span></a>
    </li>
    <?php endif; ?>
    <!-- /pengajar -->

    <?php if(auth()->user()->role == 'Peserta'): ?>
    <!-- Peserta -->
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('daftar.index')); ?>">
      <i class="fas fa-fw fa-clipboard-list"></i>
      <span>Daftar Program</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('jadwal.pertemuan')); ?>">
      <i class="fas fa-fw fa-calendar-check"></i>
      <span>Jadwal Pertemuan</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('absen.peserta')); ?>">
      <i class="fas fa-fw fa-user-check"></i>
      <span>Absensi</span></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('status.pembayaran')); ?>">
      <i class="fas fa-fw fa-credit-card"></i>
      <span>Status Pembayaran</span></a>
    </li>
    <!-- /peserta -->
    <?php endif; ?>
</ul>
<?php /**PATH C:\xampp\htdocs\maqdis\resources\views/layouts/includes/_sidebar.blade.php ENDPATH**/ ?>