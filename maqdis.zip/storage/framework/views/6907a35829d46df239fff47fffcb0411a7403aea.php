<div class="form-group">
	<label for="nmps">Nama Peserta</label>
	<input type="text" class="form-control" name="nmps" id="nmps" disabled="">
</div>

<div class="form-group">
	<label for="nmprog">Nama Program</label>
	<input type="text" class="form-control" name="nmprog" id="nmprog" disabled="">
</div>

<div class="form-group">
	<label for="nmpeng">Nama Pengajar</label>
	<input type="text" class="form-control" name="nmpeng" id="nmpeng" disabled="">
</div>

<div class="form-group">
	<label for="hari">Hari</label>
	<input type="text" class="form-control" name="hari" id="hari" disabled="">
</div>

<div class="form-group">
	<label for="waktu">Waktu</label>
	<input type="text" class="form-control" name="waktu" id="waktu" disabled="">
</div>

<div class="form-group">
	<label for="kelas">Kelas</label>
	<input type="text" class="form-control" name="kelas" id="kelas" disabled="">
</div>

<div class="form-group">
	<label for="status">Status</label>
	<input type="text" class="form-control text-primary" name="status" id="status" disabled="">
</div><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/jadwal_peserta/jadwal_peserta.blade.php ENDPATH**/ ?>