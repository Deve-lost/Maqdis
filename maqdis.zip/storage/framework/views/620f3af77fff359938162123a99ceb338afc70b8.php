<?php $__env->startSection('title', 'Profile Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <!-- DataTables Example -->
        <div class="card mb-3">
            <div class="card-header">
                Profile <?php echo e($pengguna->name); ?>

            </div>
            <div class="card-body text-center">
                <b>Nama Pengguna : <?php echo e($pengguna->name); ?></b><br>
                <b>Email : <?php echo e($pengguna->email); ?></b><br>
                <p><b>Role : <?php echo e($pengguna->role); ?></b></p>
                <a href="<?php echo e(route('pengguna.ubahpw', $pengguna->id)); ?>" class="btn btn-primary btn-sm">Ubah Password</a>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/pengguna/profile_pengguna.blade.php ENDPATH**/ ?>