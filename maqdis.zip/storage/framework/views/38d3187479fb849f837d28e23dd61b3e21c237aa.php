<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-xs-12 col-md-12 col-lg-12">
        <div class="text-center">
            <h2>Detail Pembayaran</h2>
        </div>
        <hr>
        <form action="<?php echo e(route('bayar')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-xs-12 col-md-12 col-lg-12 pull-left">
                <div class="panel panel-default height">
                    <div class="panel-heading">Pengajar</div>
                    <div class="panel-body">
                        <strong>Nama Pengajar:</strong>
                        <?php echo e($request['pengajar_id']); ?><br>
                        <strong>Nama Program:</strong>
                        <?php echo e($request['program_id']); ?><br>
                        <strong>Kelas:</strong>
                        <?php echo e($request['kelas']); ?><br>
                        <strong>Hari:</strong>
                        <?php echo e($request['hari']); ?><br>
                        <strong>Waktu:</strong>
                        <?php echo e($request['waktu']); ?><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Pembayaran</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong>Jumlah Orang</strong></td>
                                    <td class="text-center"><strong>Harga</strong></td>
                                    <td class="text-center"><strong>Biaya Pendidikan</strong></td>

                                </tr>
                            </thead>
                            <tbody>
                                <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                <?php if($request['jml_org'] == '350000'): ?>
                                    <?php
                                        $jml = 1;
                                    ?>
                                <?php elseif($request['jml_org'] == '450000'): ?>
                                    <?php
                                        $jml = 2;
                                    ?>
                                <?php elseif($request['jml_org'] == '450000'): ?>
                                    <?php
                                        $jml = 3;
                                    ?>
                                <?php elseif($request['jml_org'] == '500000'): ?>
                                    <?php
                                        $jml = 4;
                                    ?>
                                <?php elseif($request['jml_org'] == '500000'): ?>
                                    <?php
                                        $jml = 5;
                                    ?>
                                <?php elseif($request['jml_org'] == '500000'): ?>
                                    <?php
                                        $jml = 6;
                                    ?>
                                <?php elseif($request['jml_org'] == '550000'): ?>
                                    <?php
                                        $jml = 7;
                                    ?>
                                <?php elseif($request['jml_org'] == '550000'): ?>
                                    <?php
                                        $jml = 8;
                                    ?>
                                <?php elseif($request['jml_org'] == '600000'): ?>
                                    <?php
                                        $jml = 9;
                                    ?>
                                <?php elseif($request['jml_org'] == '600000'): ?>
                                    <?php
                                        $jml = 10;
                                    ?>

                                <?php endif; ?>
                                <tr>
                                    <td class="thick-line"><?php echo e($jml); ?> Orang</td>
                                    <td class="thick-line text-center"><strong>Rp.<?php echo e($request['jml_org']); ?></strong></td>
                                    <td class="thick-line text-right"><strong>Rp.<?php echo e($hrg = $request['jml_org']+100000); ?></strong></td>
                                </tr>

                                <tr>
                                    <td class="thick-line"></td>
                                    <td class="thick-line"></td>
                                    <td class="thick-line"></td>
                                </tr>

                                <tr>
                                    <td class="no-line text-primary"><span>*Biaya Pendaftaran : Rp.100.000</span></td>
                                    <td class="no-line"></td>
                                    <td class="no-line text-right"><button class="btn btn-sm btn-primary">Bayar</button></td>
                                </tr>
                            </tbody>
                        </table>


                        <input type="hidden" name="nm_pengajar" value="<?php echo e($request['pengajar_id']); ?>">
                        <input type="hidden" name="nm_program" value="<?php echo e($request['program_id']); ?>">
                        <input type="hidden" name="hari" value="<?php echo e($request['hari']); ?>">
                        <input type="hidden" name="waktu" value="<?php echo e($request['waktu']); ?>">
                        <input type="hidden" name="kelas" value="<?php echo e($request['kelas']); ?>">
                        <input type="hidden" name="harga" value="<?php echo e($hrg); ?>">
                        <input type="hidden" name="jml_org" value="<?php echo e($jml); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#addteman').on('click', function(){
            $('#addrow').append('<div class="form-group mt-3"><input type="email" class="form-control" placeholder="Masukkan Email Teman"><button class="btn btn-sm btn-danger"><i class="fa fa-trash-o"></i></button></div>');
        });

    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>