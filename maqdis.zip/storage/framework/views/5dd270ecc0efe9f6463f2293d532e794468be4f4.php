<?php $__env->startSection('title', 'Cari Pengajar'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(count($jdw) > 0): ?>
        <div class="container-fluid">
    <div class="row-fluid">
        <form action="<?php echo e(route('cobaan')); ?>" method="post" class="form-inline">
        <?php echo csrf_field(); ?>
            

        <?php $__currentLoopData = $jdw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4 pull-left mb-3">
            <div class="card-columns-fluid">
                <div class="card" style="width: 22rem;">
                    <img src="<?php echo e(asset('images/avatar/'.$data->avatar)); ?>" style="width:100px;" class="mx-auto pt-2" alt="image">
                    <div class="card-body">
                        <h5 class="card-title text-center h2"><?php echo e($data->nm_pengajar); ?></h5>
                        <p class="card-text text-center"><strong>Jenis Kelamin</strong> : <?php echo e($data->jk); ?></p>
                        <p class="card-text text-center"><strong>Pendidikan</strong> : <?php echo e($data->pendidikan); ?></p>
                        <p class="card-text text-center"><strong>Kontak</strong> : <?php echo e($data->kontak); ?></p>
                        <p class="card-text text-center"><strong>Program</strong> : <?php echo e($data->nm_program); ?></p>
                        <button class="btn btn-primary">Pesan</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name="pengajar_id" value="<?php echo e($data->nm_pengajar); ?>">
            <input type="hidden" name="kelas" value="<?php echo e($search['kelas']); ?>">
            <input type="hidden" name="program_id" value="<?php echo e($data->nm_program); ?>">
            <input type="hidden" name="waktu" value="<?php echo e($data->waktu); ?>">
            <input type="hidden" name="hari" value="<?php echo e($search['hari']); ?>">
            <input type="hidden" name="jml_org" value="<?php echo e($search['jml_org']); ?>">
        </form>
    </div>
</div>
    <?php else: ?>
        <div class="row mt-5">
            <div class="col-md-12 mt-5">
                <h3 class="text-center mt-5">Tidak Ada Pengajar Yang Sesuai.</h3>
                <p class="text-center mt-3"><a href="<?php echo e(route('daftar.index')); ?>" class="btn btn-sm btn-primary text-center">Kembali</a></p>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/daftar_program/ajax.blade.php ENDPATH**/ ?>