<?php $__env->startSection('title', 'Absensi Peserta'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 mt-3">
                <div class="card">
                    <div class="card-header">
                        <strong class="h4">Absensi</strong>
                    </div>
                    <div class="card-body">
                        <?php if($absensi > '0'): ?>
                        <form action="<?php echo e(route('absen.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="pengajar_id" value="<?php echo e($absensi->nm_pengajar); ?>">
                        <input type="hidden" name="nm_program" value="<?php echo e($absensi->nm_program); ?>">
                        <p>Nama Program : <?php echo e($absensi->nm_program); ?></p>
                        <p>Nama Pengajar : <?php echo e($absensi->nm_pengajar); ?></p>
                        <p>Kelas : <?php echo e($absensi->kelas); ?></p>

                            
        
                        <?php elseif($verif < '0'): ?>
                        <p class="mt-3">Silahkan Verifikasi Pembayaran terlebih dahulu.</p>
                        <a  href="<?php echo e(route('status.pembayaran')); ?>" class="btn btn-sm btn-primary">Status Pembayaran</a>
                        <?php endif; ?>



                        <button class="btn btn-sm btn-primary">Absen</button>
                        </form>
                    </div>
                </div>
            </div>
    </div>

    <?php if($abs > '0'): ?>
        
    <div class="row mt-3">
        <div class="col-md-12">
             <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-table"></i>
                Absensi
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                        <div class="row"><div class="col-sm-12">
                            <table class="table table-bordered dataTable table-striped" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 6px;">No</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 100px;">Nama</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 100px;">Nama Pengajar</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 21px;">Program</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 74px;">Tanggal Kegiatan</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 74px;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $abs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                   <td><?php echo e($loop->iteration); ?></td>
                                   <td><?php echo e($absen->user->name); ?></td>
                                   <td><?php echo e($absen->nm_pengajar); ?></td>
                                   <td><?php echo e($absen->nm_program); ?></td>
                                   <td><?php echo e($absen->tgl_kegiatan); ?></td>
                                   <td class="text-primary"><?php echo e($absen->absensi); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table></div></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    <?php else: ?>

    <?php endif; ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/absensi/absensi_peserta.blade.php ENDPATH**/ ?>