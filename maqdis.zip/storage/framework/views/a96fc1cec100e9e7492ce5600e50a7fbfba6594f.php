<div class="form-group">
	<label for="title">Nama Lengkap</label>
	<input type="text" class="form-control" name="nm" id="nm" disabled="">
</div>

<div class="form-group">
	<label for="pendidikan">Pendidikan</label>
	<input type="text" class="form-control" name="pendidikan" id="pendidikan" disabled="">
</div>

<div class="form-group">
	<label for="kontak">Kontak</label>
	<input type="text" class="form-control" name="kontak" id="kontak" disabled="">
</div>

<div class="form-group">
	<label for="jk">Jenis Kelamin</label>
	<input type="text" class="form-control" name="jk" id="jk" disabled="">
</div>

<div class="form-group">
	<label for="ttl">Tanggal Lahir</label>
	<input type="text" class="form-control" name="ttl" id="ttl" disabled="">
</div>

<div class="form-group">
	<label for="pengalaman">Pengalaman Kerja</label>
	<input type="text" class="form-control" name="pengalaman" id="pengalaman" disabled="">
</div>

<div class="form-group">
    <label for="alamat">Alamat</label>
    <textarea class="form-control" name="alamat" id="alamat" disabled="" rows="3"></textarea>
</div>
<?php /**PATH C:\xampp\htdocs\maqdis\resources\views/data_pengajar/profile_pengajar.blade.php ENDPATH**/ ?>