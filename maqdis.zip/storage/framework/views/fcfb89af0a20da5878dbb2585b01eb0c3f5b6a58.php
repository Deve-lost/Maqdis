<?php $__env->startSection('title', 'Status Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="row">
                
            <?php if($pembayaran > '0'): ?>
            <div class="col-md-12 mt-3">
                <div class="card text-center">
                    <div class="card-header">
                        <strong class="h4">Status Pembayaran</strong>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Nama Program : <?php echo e($pembayaran->nm_program); ?></p>
                        <p class="card-text">Nama Pengajar : <?php echo e($pembayaran->nm_pengajar); ?></p>
                        <p class="card-text">Hari : <?php echo e($pembayaran->hari); ?></p>
                        <p class="card-text">Waktu : <?php echo e($pembayaran->waktu); ?></p>
                        <p class="card-text">Biaya Pendidikan : <?php echo e($pembayaran->harga); ?></p>
                        <p class="card-text text-primary">Status : <?php echo e($pembayaran->status); ?></p>

                    </div>
                </div>
            </div>

            <?php if(!empty($pembayaran->struk)): ?>
                
            <?php else: ?>
            <div class="col-md-12">
                <br>
                <div class="text-center">Tanda Bukti Pembayaran</div>
                <form action="<?php echo e(route('update.struk', $pembayaran->user_id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
            <center>
            <br/>
            <div class="form-group" <?php echo e($errors->has('struk') ? ' has-error' : ''); ?>>
            <img id="preview" src="<?php echo e(asset('images/default.svg')); ?>" width="230px" height="220px"/><br/>
            <input type="file" name="struk" id="image" style="display: none;"/>
            <!--<input type="hidden" style="display: none" value="0" name="remove" id="remove">-->
            <a href="javascript:changeProfile()">Pilih</a> |
            <a style="color: red" href="javascript:removeImage()">Remove</a> <br> <br>
            <span>Silahkan Upload Struk Pembayaran</span> <br>
            <?php if($errors->has('struk')): ?>
              <span class="help-block text-danger"><?php echo e($errors->first('struk')); ?></span>
            <?php endif; ?>
            </center>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <script>
            function changeProfile() {
            $('#image').click();
            }
            $('#image').change(function () {
            var imgPath = this.value;
            var ext = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
            if (ext == "gif" || ext == "png" || ext == "jpg" || ext == "jpeg")
            readURL(this);
            else
            alert("Please select image file (jpg, jpeg, png).")
            });
            function readURL(input) {
            if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.readAsDataURL(input.files[0]);
            reader.onload = function (e) {
            $('#preview').attr('src', e.target.result);
            //              $("#remove").val(0);
            };
            }
            }
            function removeImage() {
            $('#preview').attr('src', '<?php echo e(asset('images/default.svg')); ?>');
            //      $("#remove").val(1);
            }
            </script>
            </div>
            <button class="btn btn-sm btn-primary mx-auto mt-2 mb-4">Upload</button>

                </form>
            </div>
            <?php endif; ?>

            <?php else: ?>
            <div class="col-md-12 mt-3">
                <div class="card text-center">
                    <div class="card-header">
                        <strong class="h4">Status Pembayaran</strong>
                    </div>
                    <div class="card-body">
                        <p class="card-title h5">Belum mendaftar program</p>
                        <a href="<?php echo e(route('daftar.index')); ?>" class="btn btn-primary">Daftar Program</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/pembayaran/status_pembayaran.blade.php ENDPATH**/ ?>