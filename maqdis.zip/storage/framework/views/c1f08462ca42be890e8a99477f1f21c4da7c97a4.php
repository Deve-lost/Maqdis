<?php $__env->startSection('title', 'Tambah Pengajar'); ?>

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container">
        <div class="container-fluid">
            <form action="<?php echo e(route('dp.store')); ?>" class="form-horizontal" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mx-auto mt-5 justify-content-center">
                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('nm_pengajar') ? ' has-error' : ''); ?>">
                            <label for="nm_pengajar" class="col-xs-3 control-label">Nama Pengajar</label>
                            <div class="col-xs-9">
                                <input type="text" class="form-control" id="nm_pengajar" name="nm_pengajar" placeholder="Masukkan Nama Pengajar" value="<?php echo e(old('nm_pengajar')); ?>">
                            </div>
                            <?php if($errors->has('nm_pengajar')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('nm_pengajar')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-xs-3 control-label">Email</label>
                            <div class="col-xs-9">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email Pengajar" value="<?php echo e(old('email')); ?>">
                            </div>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('pendidikan') ? ' has-error' : ''); ?>">
                            <label for="pendidikan" class="col-xs-3 control-label">Pendidikan</label>
                            <div class="col-xs-9">
                                <input type="text" class="form-control" id="pendidikan" name="pendidikan" placeholder="Pendidikan Terakhir" value="<?php echo e(old('pendidikan')); ?>">
                            </div>
                            <?php if($errors->has('pendidikan')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('pendidikan')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('kontak') ? ' has-error' : ''); ?>">
                            <label for="kontak" class="col-xs-3 control-label">Kontak</label>
                            <div class="col-xs-9">
                                <input type="text" class="form-control" id="kontak" name="kontak" placeholder="No Wa/Hp" value="<?php echo e(old('kontak')); ?>">
                            </div>
                            <?php if($errors->has('kontak')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('kontak')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="jk" class="col-xs-3 control-label">Jenis Kelamin</label>
                            <div class="col-xs-9">
                                <select class="form-control" id="jk" name="jk">
                                  <option value="Laki-Laki" <?php echo e((old('jk') == 'Laki-Laki') ? ' selected' : ''); ?>>Laki-Laki</option>
                                  <option value="Perempuan" <?php echo e((old('jk') == 'Perempuan') ? ' selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('ttl') ? ' has-error' : ''); ?>">
                            <label for="ttl" class="col-xs-3 control-label">Tanggal Lahir</label>
                            <div class="col-xs-9">
                                <input type="text" class="form-control" id="ttl" name="ttl" value="<?php echo e(old('ttl')); ?>" placeholder="Kab/Kota, Tanggal Bulan Tahun">
                            </div>
                            <?php if($errors->has('ttl')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('ttl')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-10">
                        <div class="form-group <?php echo e($errors->has('avatar') ? ' has-error' : ''); ?>">
                            <label for="avatar" class="col-xs-3 control-label">Avatar</label>
                            <div class="col-xs-9">
                                <input type="file" class="" id="avatar" name="avatar" placeholder="No Wa/Hp">
                            </div>
                            <?php if($errors->has('avatar')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('avatar')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('pengalaman_kerja') ? ' has-error' : ''); ?>">
                            <label for="pengalaman_kerja" class="col-xs-3 control-label">Pengalaman Kerja</label>
                            <div class="col-xs-9">
                                <textarea class="form-control" id="pengalaman_kerja" rows="3" name="pengalaman_kerja"><?php echo e(old('pengalaman_kerja')); ?></textarea>
                            </div>
                            <?php if($errors->has('pengalaman_kerja')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('pengalaman_kerja')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                            <label for="alamat" class="col-xs-3 control-label">Alamat</label>
                            <div class="col-xs-9">
                                <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo e(old('alamat')); ?></textarea>
                            </div>
                            <?php if($errors->has('alamat')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('alamat')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-10 mt-3">
                        <div class="form-group">
                            <div class="col-xs">
                                <button type="submit" class="btn btn-primary btn-sm">Tambah Data</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/data_pengajar/create_dp.blade.php ENDPATH**/ ?>