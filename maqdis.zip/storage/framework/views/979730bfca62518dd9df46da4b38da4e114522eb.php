<div class="form-group">
	<label for="nm">Nama Peserta</label>
	<input type="text" class="form-control" name="nm" id="nm" disabled="">
</div>

<div class="form-group">
	<label for="jmlorg">Jumlah Orang</label>
	<input type="text" class="form-control" name="jmlorg" id="jmlorg" disabled="">
</div>

<div class="form-group">
	<label for="nmprog">Nama Program</label>
	<input type="text" class="form-control" name="nmprog" id="nmprog" disabled="">
</div>

<div class="form-group">
	<label for="nmpeng">Nama Pengajar</label>
	<input type="text" class="form-control" name="nmpeng" id="nmpeng" disabled="">
</div>

<div class="form-group">
	<label for="hari">Hari</label>
	<input type="text" class="form-control" name="hari" id="hari" disabled="">
</div>

<div class="form-group">
	<label for="waktu">Waktu</label>
	<input type="text" class="form-control" name="waktu" id="waktu" disabled="">
</div>

<div class="form-group">
	<label for="kelas">Kelas</label>
	<input type="text" class="form-control" name="kelas" id="kelas" disabled="">
</div>

<div class="form-group">
	<label for="harga">Harga</label>
	<input type="text" class="form-control" name="harga" id="harga" disabled="">
</div>

<div class="form-group">
	<label for="status">Status</label>
	<input type="text" class="form-control" name="status" id="status" disabled="">
</div>
<div class="form-group">
	<label for="struk">Struk</label>
	<img src="<?php echo e(asset('images/struk/')); ?>" alt="" name="struk" id="gambar" style="width: 100%">
</div>

<?php /**PATH C:\xampp\htdocs\maqdis\resources\views/konfirmasi_pembayaran/konfirmasi.blade.php ENDPATH**/ ?>