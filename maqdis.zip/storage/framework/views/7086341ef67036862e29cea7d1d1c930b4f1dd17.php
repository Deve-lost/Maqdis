<?php $__env->startSection('title', 'Tambah Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container">
        <div class="container-fluid">
            <form action="<?php echo e(route('jp.store')); ?>" class="form-horizontal" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mx-auto mt-5 justify-content-center">
                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('pengajar_id') ? ' has-error' : ''); ?>">
                            <label for="pengajar_id" class="col-xs-3 control-label">Pengajar</label>
                            <div class="col-xs-9">
                                <select class="form-control" id="pengajar_id" name="pengajar_id">
                                    <option selected="">-- Pilih Pengajar --</option>
                                    <?php $__currentLoopData = $pengajars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pengajar->id); ?>"><?php echo e($pengajar->nm_pengajar); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('pengajar_id')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('pengajar_id')); ?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                        
                        <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('program_id') ? ' has-error' : ''); ?>">
                            <label for="program_id" class="col-xs-3 control-label">Program</label>
                            <div class="col-xs-9">
                                <select class="form-control" id="program_id" name="program_id">
                                    <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prog->id); ?>"><?php echo e($prog->nm_program); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php if($errors->has('program_id')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('program_id')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('waktu') ? ' has-error' : ''); ?>">
                            <label for="waktu" class="col-xs-3 control-label">Waktu</label>
                            <div class="col-xs-9">
                                <select class="form-control" id="waktu" name="waktu">
                                  <option value="08.00 WIB">O8.00 WIB</option>
                                  <option value="10.00 WIB">10.00 WIB</option>
                                  <option value="13.00 WIB">13.00 WIB</option>
                                  <option value="15.30 WIB">15.30 WIB</option>
                                </select>
                            </div>
                            <?php if($errors->has('waktu')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('waktu')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group <?php echo e($errors->has('kelas') ? ' has-error' : ''); ?>">
                            <label for="kelas" class="col-xs-3 control-label">Kelas</label>
                            <div class="col-xs-9">
                                <select class="form-control" id="kelas" name="kelas">
                                  <option value="Dekat">Dekat</option>
                                  <option value="Jauh">Jauh</option>
                                  <option value="Malam">Malam</option>
                                  <option value="Jauh + Malam">Jauh + Malam</option>
                                </select>
                            </div>
                            <?php if($errors->has('kelas')): ?>
                                <span class="help-block text-danger"><?php echo e($errors->first('kelas')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                 
                <div class="col-md-10 mt-3">
                    <div class="form-group">
                        <div class="col-xs">
                            <button type="submit" class="btn btn-primary btn-sm">Tambah Data</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/jadwal/create_jp.blade.php ENDPATH**/ ?>