<?php $__env->startSection('title', 'Data Peserta'); ?>

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Data Peserta</li>
    </ol>
    <!-- DataTables Example -->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fas fa-table"></i>
        Data Peserta
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
            <div class="row">
              <div class="col-sm-12">
                  <form action="<?php echo e(route('tambah.kelompok', $idp->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <table class="table table-bordered dataTable table-striped" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                  <thead>
                    <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 6px;">No</th>
                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 40px;">Nama Peserta</th>
                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 50px;">Email</th>
                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 74px;">Jenis Kelamin</th>
                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 1px;">Kontak</th>
                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 20px;">Opsi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr role="row" class="odd">
                      <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                      <td class="sorting_1"><?php echo e($data->nama); ?></td>
                      <td><?php echo e($data->email); ?></td>
                      <td><?php echo e($data->jk); ?></td>
                      <td><?php echo e($data->kontak); ?></td>
                      <td>
                        <label class="btn btn-primary control-inline fancy-checkbox <?php echo e($errors->has('add') ? 'has-error' : ''); ?>">
                          <input type="checkbox" name="add[]" value="<?php echo e($data->id); ?>">
                          <span></span>
                          <?php if($errors->has('add')): ?>
                          <span class="help-block">
                            <p><?php echo e($errors->first('add')); ?></p>
                          </span>
                          <?php endif; ?>
                        </label>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr role="row" class="odd">
                      <td class="sorting_1" colspan="7">Data tidak ditemukan.</td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <td class="border-right-0"></td>
                    <td class="border-right-0"></td>
                    <td class="border-right-0"></td>
                    <td class="border-right-0"></td>
                    <td></td>
                    <td><button type="submit" class="btn btn-sm btn-primary">Tambah</button></td>
                  </tr>
                </tfoot>
                </form>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->
<!-- Modal -->
<div class="modal fade" id="showpeserta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Profile Peserta</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <?php echo $__env->make('peserta.profile_peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
     </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script type="text/javascript">
        $('.delete').click(function(){
            var peserta_id = $(this).attr('peserta-id');
            var peserta_nm = $(this).attr('peserta-nm');
            swal({
                  title: "Hapus!",
                  text: "Peserta "+peserta_nm+"?",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                })
                .then((willDelete) => {
                  if (willDelete) {
                    window.location = "/Maqdis/destroy/"+peserta_id+"/peserta";
                  }
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/peserta/tambah_peserta.blade.php ENDPATH**/ ?>