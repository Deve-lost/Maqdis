<?php $__env->startSection('title', 'Jadwal Pertemuan'); ?>

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <!-- DataTables Example -->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-table"></i>
                Jadwal Pertemuan
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                        <div class="row"><div class="col-sm-12">
                            <table class="table table-bordered dataTable table-striped" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 6px;">No</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 100px;">Nama</th>
                                    
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 21px;">Program</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 74px;">Hari</th>
                                    <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 74px;">Waktu</th>
                                    
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $id = auth()->user()->id;
                                    $no = 1;
                                ?>
                                <?php if($pembayaran > '0'): ?>
                                <tr role="row" class="odd">
                                    <td class="sorting_1"><?php echo e($no++); ?></td>
                                    <td class="sorting_1"><?php echo e(auth()->user()->name); ?></td>
                                    
                                    <td class="sorting_1"><?php echo e($pembayaran->nm_program); ?></td>
                                    <td class="sorting_1"><?php echo e($pembayaran->hari); ?></td>
                                    <td class="sorting_1"><?php echo e($pembayaran->waktu); ?></td>
                                    
                                    
                                </tr>
                                <?php else: ?>
                                <tr role="row" class="odd">
                                    <td class="sorting_1" colspan="8">Data tidak ditemukan.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maqdis\resources\views/jadwal_pertemuan/jadwal_pengajar.blade.php ENDPATH**/ ?>