<div class="form-group">
	<label for="nm">Nama Lengkap</label>
	<input type="text" class="form-control" name="nm" id="nm" disabled="">
</div>

<div class="form-group">
	<label for="email">Email</label>
	<input type="text" class="form-control" name="email" id="email" disabled="">
</div>

<div class="form-group">
	<label for="jk">Jenis Kelamin</label>
	<input type="text" class="form-control" name="jk" id="jk" disabled="">
</div>

<div class="form-group">
	<label for="kontak">Kontak</label>
	<input type="text" class="form-control" name="kontak" id="kontak" disabled="">
</div>

<div class="form-group">
	<label for="ttl">Tanggal Lahir</label>
	<input type="text" class="form-control" name="ttl" id="ttl" disabled="">
</div>

<div class="form-group">
    <label for="alamat">Alamat</label>
    <textarea class="form-control" name="alamat" id="alamat" disabled="" rows="3"></textarea>
</div>
